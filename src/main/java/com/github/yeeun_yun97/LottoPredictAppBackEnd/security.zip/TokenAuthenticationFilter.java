package com.github.yeeun_yun97.LottoPredictAppBackEnd.security;

import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class TokenAuthenticationFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

    }
//    @Autowired
//    private AuthenticationTokenProvider authenticationTokenProvider;
//
//    @Autowired
//    private UserService userService;
//
//    @SneakyThrows
//    @Override
//    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//            throws ServletException, IOException {
//        String token = authenticationTokenProvider.parseTokenString(request);
//        if (authenticationTokenProvider.validateToken(token)) {
//            Long userNo = authenticationTokenProvider.getTokenOwnerNo(token);
//            try {
//                User member = (User) userService.loadUserByUsername(userNo.toString());
//                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(member,
//                        member.getPassword(), member.getAuthorities());
//                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//                SecurityContextHolder.getContext().setAuthentication(authentication);
//            } catch (UsernameNotFoundException e) {
//                throw new UsernameNotFoundException("유효하지않은 인증토큰 입니다. 인증토큰 회원 정보 오류");
//            }
//        }
//        filterChain.doFilter(request, response);
//    }
}