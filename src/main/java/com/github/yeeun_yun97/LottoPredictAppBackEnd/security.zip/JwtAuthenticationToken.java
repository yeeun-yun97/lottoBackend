package com.github.yeeun_yun97.LottoPredictAppBackEnd.security;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class JwtAuthenticationToken {
    private String token;


}


